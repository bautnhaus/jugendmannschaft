# PROD-Migrationen 1–43 – Rekonstruktionsarbeitsstand

**Erstellt:** 03.11.2026  
**Quelle:** Nutzer-Upload `Sql.zip`  
**SHA-256 der unveränderten ZIP:** `ca258b5fa738427ce38a5d4f43a956b04c69ad5d2295f5cdf0e4408e11406a7f`  
**Zielumgebung:** PROD – vom Nutzer ausdrücklich für alle 43 SQL-Anfragen bestätigt.  
**Ausführung/Prüfung:** Der Nutzer bestätigt, dass alle 43 Anfragen in PROD erfolgreich ausgeführt und im damaligen Chat geprüft wurden. Die einzelnen Prüf-SQLs und Prüfergebnisse sind nicht in der ZIP enthalten und wurden hier nicht erneut eingesehen.

## Inhalt
- `original_sql/`: 43 Originaldateien bytegetreu aus `Sql.zip` extrahiert. Die Dateiendung `.sql.txt` macht deutlich, dass es sich um unveränderte Textdateien handelt.
- `MIGRATIONEN_01-43_MATRIX.md`: Inventar, technische Einordnung, Prüfnachweise und Abgleich mit vorhandener Dokumentation.

## Verbindliche Nachweisgrenzen
1. Die Original-SQL-Texte sind durch die hochgeladene ZIP belegt.
2. PROD als Zielumgebung und erfolgreiche Ausführung/Prüfung sind Nutzerbestätigung.
3. Exakte Ausführungszeitpunkte, Ausführungsweg je Migration, ausführende Person, konkrete read-only Prüf-SQLs und Resultate sind mit den vorliegenden Dateien nicht einzeln belegt.
4. Die ZIP und die daraus erstellten Prüfsummen beweisen keine Datenbankausführung.
5. Es wurden keine SQL-Anweisungen ausgeführt, keine Datenbank abgefragt oder verändert und keine GitHub-Dateien verändert.

## Integritätsprüfung
- Alle 43 extrahierten SQL-Dateien wurden bytegenau mit den jeweiligen Einträgen `Sql/MigrationNN.txt` aus der vom Nutzer bereitgestellten `Sql.zip` verglichen. Alle 43 Vergleiche waren identisch.
- `SHA256SUMS.txt` enthält die SHA-256-Prüfsummen der archivierten Originaldateien.
- Die Dateiendung `.sql.txt` wurde nur für die Ablage vergeben; der Dateiinhalt wurde nicht verändert.
